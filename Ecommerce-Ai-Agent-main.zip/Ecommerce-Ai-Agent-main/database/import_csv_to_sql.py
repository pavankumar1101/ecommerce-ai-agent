import sqlite3
import pandas as pd
import os

# Target DB file
db_path = "database/ecommerce.db"

# Folder where CSVs are located
csv_folder = os.path.join("database", "csv")

# Map CSV filenames to table names
files_to_tables = {
    "Ad_Sales.csv": "ad_sales",
    "Eligibility.csv": "eligibility",
    "Total_Sales.csv": "total_sales"
}

# Connect to DB
conn = sqlite3.connect(db_path)

# Load each CSV
for filename, table_name in files_to_tables.items():
    file_path = os.path.join(csv_folder, filename)
    
    if not os.path.exists(file_path):
        print(f"❌ File not found: {file_path}")
        continue
    
    print(f"✅ Loading {filename} → Table: {table_name}")
    df = pd.read_csv(file_path)
    df.to_sql(table_name, conn, if_exists="replace", index=False)

# Close DB
conn.close()
print("🎉 All CSVs loaded into ecommerce.db successfully!")

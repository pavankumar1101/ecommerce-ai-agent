import matplotlib.pyplot as plt
import io
import base64
import pandas as pd

def generate_chart(df: pd.DataFrame) -> str:
    plt.figure(figsize=(10, 5))
    df.plot(kind="bar", legend=True)
    buf = io.BytesIO()
    plt.savefig(buf, format='png')
    buf.seek(0)
    img_base64 = base64.b64encode(buf.read()).decode('utf-8')
    return img_base64


from fastapi.middleware.cors import CORSMiddleware
from app.models import QueryInput
from app.llm_utils import generate_sql
from app.sql_utils import execute_sql
from app.visualization import generate_chart
from fastapi.responses import StreamingResponse
from fastapi import FastAPI

app = FastAPI()

@app.get("/")
def read_root():
    return {"message": "API is running! Visit /docs for Swagger UI."}


# CORS settings for frontend
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

@app.post("/ask")
def ask_question(input: QueryInput):
    sql_query = generate_sql(input.question)
    try:
        df = execute_sql(sql_query)
        return {"sql": sql_query, "answer": df.to_dict(orient="records")}
    except Exception as e:
        return {"error": str(e), "sql_attempted": sql_query}

@app.post("/ask/graph")
def ask_with_graph(input: QueryInput):
    sql_query = generate_sql(input.question)
    df = execute_sql(sql_query)
    chart = generate_chart(df)
    return {"sql": sql_query, "chart": chart}

@app.post("/ask/stream")
def stream_response(input: QueryInput):
    sql_query = generate_sql(input.question)
    df = execute_sql(sql_query)

    def stream_rows():
        yield f"SQL Used: {sql_query}\n"
        for _, row in df.iterrows():
            yield str(row.to_dict()) + "\n"

    return StreamingResponse(stream_rows(), media_type="text/plain")

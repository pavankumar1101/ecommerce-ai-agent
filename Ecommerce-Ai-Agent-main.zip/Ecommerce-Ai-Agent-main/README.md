# Ecommerce-Ai-Agent
This project implements an AI-powered backend system that allows users to ask natural language questions about e-commerce product performance, and receive accurate answers by converting those questions into SQL queries over structured datasets.
